import sqlite3
from flask import g

def DB_connection():
	try:
		con = sqlite3.connect('sprint3.db')
		return con
	except Error:
		print(Error)

def insert_user(name,lastname,email,password,phone,address):
	query = "INSERT INTO users (name,lastname,email,password,phoneNumber,address) VALUES (?,?,?,?,?,?)"
	con = DB_connection()
	
	try:
		cursor = con.cursor()
		cursor.execute(query, (name,lastname,email,password,phone,address))
		con.commit()
		msg = 'User successfully added'
	except:
		con.rollback()
		msg = 'Error in insert operation'
	finally:
		con.close()

	return msg

def login_user(email,password):
	query = "SELECT * FROM users WHERE email=? AND password=?"
	con = DB_connection()

	try:
		cursor = con.cursor()
		cursor.execute(query, (email,password))
		cursor = cursor.fetchone()
	except:
		cursor = None
	finally:
		con.close()

	return cursor

def get_user_by_id(id_user):
	query = "SELECT * FROM users WHERE id_user=?"
	con = DB_connection()

	try:
		cursor = con.cursor()
		cursor.execute(query, (id_user))
		cursor = cursor.fetchone()
	except:
		cursor = None
	finally:
		con.close()

	return cursor

def update_user(id_user,name,lastname,email,phone,address):
	query = "UPDATE users SET name=?,lastname=?,email=?,phoneNumber=?,address=? WHERE id_user=?"
	con = DB_connection()
	try:
		cursor = con.cursor()
		cursor.execute(query, (name,lastname,email,phone,address,id_user))
		con.commit()
		msg = 'Your Data was successfully UPDATED'
	except:
		con.rollback()
		msg = 'Error in UPDATE operation'
	finally:
		con.close()

	return msg

def delete_user(id_user):
	query = "DELETE FROM users WHERE id_user=?"

	con = DB_connection()
	try:
		cursor = con.cursor()
		cursor.execute(query, (id_user))
		con.commit()
		msg = 'Your Data was successfully DELETED'
	except:
		con.rollback()
		msg = 'Error in DELETE operation'
	finally:
		con.close()

	return msg