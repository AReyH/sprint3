from files import utils, comments,DBManager 

##import forms

from flask import Flask
from flask import render_template, url_for,redirect,request,flash, redirect
import random
import sqlite3

import os

app = Flask(__name__)

app.secret_key = os.urandom(24)




@app.route('/')
def index():
    return render_template('Home.html')

# HOME

@app.route('/home',methods=['GET','POST'])
def home():
    return render_template('index_inicial.html')



# REGISTRO

@app.route('/registro',methods=['GET','POST'])
def registro():

    #Get data from register form
    if request.method == 'POST':
        name = request.form['name']
        lastname = request.form['lastname']

        email = request.form['email']
        password = request.form['password']

        phone = request.form['phonenumber']
        address = request.form['address']

    #validate username, password and email
    #pip install validate_email
        if (not utils.isUsernameValid(name)):
            error = 'User must be alphanumeric'
            flash(error)
            return render_template('registro.html')

        elif(name=='' or name==None):
            error = 'Please enter your Name'
            flash(error)
            return render_template('registro.html')

        

        if not utils.isPasswordValid(password):
            error = "Invalid Password"
            flash(error)
            return render_template('registro.html')

        if not utils.isEmailValid(email):
            error = "Invalid Email"
            flash(error)
            return render_template('registro.html')

        if (utils.isUsernameValid(name) and utils.isPasswordValid(password) and 
            utils.isEmailValid(email)):

            msg = DBManager.insert_user(name,lastname,email,password,phone,address)
            flash(msg)

            return redirect('login')

    if(request.method == 'GET'):
        return render_template('registro.html')


# LOGIN

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        validate_user = DBManager.login_user(email, password)

        if validate_user is None:
            error = 'Incorrect email or password'
            flash(error)
        else:
            return render_template('usuarios/perfilUsuario.html', user_data=validate_user)


        # if email == 'Prueba' and password == 'Prueba123':
        #     return redirect('usuarios')
        # elif email == 'ADMIN' and password == 'PruebaAdmin':
        #     return redirect('usuarios/admin')
        # elif (email == '' or password == ''):
        #     flash('User and password could not be empty')
        # else:
        #     flash('Incorrect data')
            
        #     return render_template('login2.html')



    return render_template('login2.html')



# MENU

@app.route('/menu',methods=['GET'])
def menu():
    return render_template('menu.html')

@app.route('/menu/busqueda',methods=['GET','POST'])
def busqueda():
    return render_template('busqueda.html')

@app.route('/menu/lista_deseos',methods=['GET','POST','PUT'])
def lista_deseos():
    return 'lista_deseos'

#PLATOS - CRUD METHODS

@app.route('/menu/platos',methods=['GET','POST'])
def platos():
    
    return render_template('productos/Productos.html')

@app.route('/menu/platos/detalle_plato',methods=['GET'])
def detalle_plato():
    return render_template('productos/almojabana.html')

@app.route("/menu/platos/agregar_plato", methods=['GET','POST'])
def agregar_plato():
    return 'agregar Plato'


#COMENTARIOS

@app.route('/comentarios',methods=['GET','POST'])
def comentarios():
    
    comentarios = comments.comentarios # folder: files, file: comments, list: 'comentarios'

    return render_template('comentarios/comments.html', comments= comentarios)

@app.route('/comentarios/insert', methods=['GET','POST'])
def insert_comment():
    comentarios = comments.comentarios

    if request.method == 'GET':
        return render_template('comentarios/insert_comment.html')

    if request.method == 'POST':
        id_comentario = str(random.randint(10,100))
        id_autor = str(random.randint(10,100))
        id_plato = str(random.randint(10,100))
        comentario = request.form['comentario']

        day = str(random.randint(1,31))
        month = str(random.randint(1,12))
        year = str(random.randint(2019,2021))
        fecha = day + '/' + month + '/' + year

        new_comment = comments.Comment(id_comentario,id_autor,id_plato, comentario, fecha)
        comentarios.append(new_comment)
        flash('Comment Added')
        return render_template('comentarios/comments.html', comments = comentarios)


@app.route('/comentarios/update',methods=['GET','POST'] )
def update_comment():
    
    
        flash('Comment Updated')
        return redirect(url_for('comentarios'))

@app.route('/comentarios/delete',methods=['GET','POST'] )
def delete_comment():
    

        flash('Comment Deleted')
        return redirect(url_for('comentarios'))



@app.route('/menu/pedidos',methods=['GET','POST','PUT'])
def pedidos():
    return 'pedidos'

#implementar busqueda por categoria, ej: tortas, pasteles, galletas
@app.route('/menu/busqueda/<string:categoria>',methods=['GET'])
def resultados(categoria):
    dict = {
        'galletas': ['galleta de coco', 'galleta de avena', 'galleta de chocolate'],
        'pan':['rollo','frances','mogollas'],
        'tortas':['mousse de chocolate','tarta de fresas','pie de manzana']
    }
    return f'Resultado de la busqueda por Categoria: {dict[categoria]}'

#implementar busqueda por id del plato
@app.route('/menu/busqueda/platos/<string:id_plato>',methods=['GET'])
def get_platos(id_plato):
    dict2 = {'plato1':'tortas', 'plato2':'hojaldres','plato3':'chessecake'}

    return f'Resultado de la busqueda por Id Producto: {dict2[id_plato]}'




#PERFIL DE USUARIOS
@app.route('/usuarios', methods=['GET','POST'])
def usuarios():
    return render_template('usuarios/perfilUsuario.html')

@app.route('/usuarios/admin', methods=['GET','POST'])
def admin():
    return render_template('usuarios/perfilAdmin.html')

@app.route('/usuarios/<string:id_usuario>', methods=['GET'])
def get_user_by_id(id_usuario):
    usuarios = ['Fabian','Carolina','Leonardo', 'Raul', 'Arturo','Daniel']
    if id_usuario in usuarios:
        return f'Bienvenido {id_usuario}'
    else:
        return 'Usuario no encontrado'


#USUARIOS: EDITAR USUARIO
@app.route('/usuarios/edit/<id_user>', methods=['GET','POST'])
def edit_user_data(id_user):
    
    if request.method=='GET':
        user_data = DBManager.get_user_by_id(id_user)
        return render_template('usuarios/updateUser.html', user_data = user_data)

    if request.method=='POST':
        
        name = request.form['name']
        lastname = request.form['lastname']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']

        msg = DBManager.update_user(id_user,name,lastname,email,phone,address)

        flash(msg)
        user_data = DBManager.get_user_by_id(id_user)
        return render_template('usuarios/perfilUsuario.html', user_data=user_data)

#USUARIOS: ELIMINAR USUARIO (ELIMINAR CUENTA)
@app.route('/usuarios/delete/<id_user>', methods=['GET','POST'])
def delete_user_data(id_user):

    msg = DBManager.delete_user(id_user)

    flash(msg)

    return redirect(url_for('registro'))


#CODIGO CAROLINA
def sql_connection():
    con= sqlite3.connect('sprint3.db')
    return con

@app.route('/usuarios/admin/gestionarproductos', methods=['GET','POST'])
def agregarproductos():
    con= sql_connection()
    cur= con.cursor()
    cur.execute('SELECT * FROM productos')
    data = cur.fetchall()
    return render_template ('productos/agregarproductos.html', contact = data)

@app.route('/usuarios/admin/add_product', methods= ['POST'])
def add_contact():
    if request.method == 'POST':
        con= sql_connection()
        nombreproducto = request.form['nombreproducto']
        descripcionproducto = request.form['descripcionproducto']
        precioproducto = request.form['precioproducto']
        cur= con.cursor()
        statement= 'INSERT INTO productos (nombreproducto, descripcionproducto, precioproducto) VALUES (?,?,?)'
        cur.execute (statement, [nombreproducto, descripcionproducto, precioproducto])
        con.commit()
        flash('Producto agregado exitosamente')

    return redirect(url_for('agregarproductos'))

@app.route('/usuarios/admin/edit/<id>', methods=['GET'])
def edit_contact(id):
    con= sql_connection()
    cur= con.cursor()
    statement= 'SELECT* from productos WHERE id=?'
    cur.execute(statement, [id])
    data= cur.fetchone()
    return render_template('productos/editarproductos.html', contact= data)


@app.route('/usuarios/admin/updateproducto/<int:id>', methods=['POST'])
def update(id):
    if request.method == 'POST':
        con = sql_connection()
        nombreproducto = request.form['nombreproducto']
        descripcionproducto = request.form['descripcionproducto']
        precioproducto = request.form['precioproducto']        
        cur = con.cursor()
        statement = 'UPDATE productos set nombreproducto=?, descripcionproducto=?, precioproducto=? WHERE id=?'
        cur.execute(statement, [nombreproducto, descripcionproducto, precioproducto, id])
        print('Update')
        flash('Producto editado exitosamente')
        con.commit()
    return redirect(url_for('agregarproductos'))

@app.route('/usuarios/admin/deleteproducto/<id>', methods=['GET','POST'])
def delete_contact(id):
    con = sql_connection()
    cur= con.cursor()
    statement = 'DELETE FROM productos WHERE id ={0}'.format(id)
    cur.execute(statement)
    con.commit()
    flash('Producto eliminado exitosamente')
    return redirect(url_for('agregarproductos'))




# NOSOTROS

@app.route('/nosotros',methods=['GET'])
def nosotros():
    return 'Nosotros'




if __name__ == '__main__':
    app.run(debug=True)